package code.faizal.rakaminchallenge.core.domain.model

data class Source(
    val id: String? = "",
    val name :String? = ""
)
