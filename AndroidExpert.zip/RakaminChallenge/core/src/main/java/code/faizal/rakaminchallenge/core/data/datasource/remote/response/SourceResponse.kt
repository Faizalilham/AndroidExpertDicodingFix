package code.faizal.rakaminchallenge.core.data.datasource.remote.response

data class SourceResponse(
    val id: String? = "",
    val name :String? = ""
)
