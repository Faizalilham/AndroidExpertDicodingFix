package code.faizal.rakaminchallenge.core.data.datasource.local.entity



data class SourceEntity(
    val id: String? = "",

    val name :String? = ""
)
